# C8 — Quản lý thanh toán

## Mô tả
Quản lý vòng đời thanh toán: bệnh nhân thanh toán mock khi đặt lịch (timeout 15 phút nếu không thanh toán), Admin duyệt hoàn tiền. Có xử lý đầy đủ các trường hợp đặc biệt.

## Đối tượng sử dụng
| Người dùng | Vai trò |
|---|---|
| Bệnh nhân | Thanh toán khi đặt lịch |
| Admin | Xem payments, duyệt/từ chối refund, xem thống kê |

## Luồng nghiệp vụ

### 1. Thanh toán khi đặt lịch
1. Sau khi tạo lịch hẹn `pending`, bệnh nhân thấy trang thanh toán mock.
2. Nhấn "Xác nhận thanh toán" → `payments.status = 'paid'`, `appointments.payment_status = 'paid'`.
3. **Nếu bệnh nhân không thanh toán trong 15 phút:**
   - Cron phát hiện appointment `unpaid` quá 15 phút.
   - Tự hủy lịch: `appointments.status = 'cancelled'`, giảm `slot.current_patients`.
   - Không tạo refund (chưa có tiền).

### 2. Hoàn tiền khi hủy lịch (tự động tính %)
Được kích hoạt khi:
- Bệnh nhân hủy lịch `paid` (A5)
- Bác sĩ từ chối lịch (B3)
- Admin hủy khẩn cấp (C5)

Hệ thống tính:
- % hoàn tiền theo bảng chính sách.
- Tạo `refunds` với `status = 'pending'`.

**Trường hợp đặc biệt:**
- `payment_status = 'unpaid'` → hủy ngay, **không tạo refund**.

### 3. Admin duyệt hoàn tiền
1. Vào tab "Hoàn tiền" — danh sách refund `pending`.
2. Nhấn "Duyệt" → `refunds.status = 'completed'`, `appointments.payment_status = 'refunded'`.
3. Gửi email xác nhận cho bệnh nhân.

### 4. Admin từ chối hoàn tiền
1. Nhấn "Từ chối", bắt buộc nhập lý do.
2. `refunds.status = 'rejected'`.
3. `appointments.payment_status` giữ nguyên `'paid'` (tiền chưa hoàn).
4. Gửi email kèm lý do.
5. **Bệnh nhân không thể tạo refund lại** cho cùng lịch hẹn đó.

### 5. Xem thống kê doanh thu
1. Admin xem tổng doanh thu theo tháng.
2. Biểu đồ theo tuần/tháng.
3. Tỉ lệ hoàn tiền.

## Chính sách hoàn tiền
| Thời gian còn lại | % Được hoàn |
|---|---|
| ≥ 24 giờ | 100% |
| 12 – 24 giờ | 80% |
| 6 – 12 giờ | 50% |
| < 6 giờ | 0% |
| Bác sĩ từ chối | 100% bất kể thời gian |
| Admin hủy khẩn cấp | 100% bất kể thời gian |
| Lịch unpaid khi hủy | 0% (không có tiền để hoàn) |

## Vòng đời payment_status
```
unpaid → [15 phút timeout] → appointment cancelled (không tạo refund)
unpaid → paid             (bệnh nhân thanh toán)
paid   → refunded         (refund completed)
paid   → (giữ nguyên)     (refund rejected)
```

## Bảng dữ liệu liên quan
| Bảng | Mục đích |
|---|---|
| `payments` | Ghi nhận thanh toán |
| `refunds` | Yêu cầu hoàn tiền (1 lịch = tối đa 1 refund) |
| `payment_settings` | Cấu hình tỉ lệ (không hardcode) |
| `appointments` | payment_status đồng bộ |

## API Endpoints
| Method | Endpoint | Auth | Mô tả |
|---|---|---|---|
| POST | `/api/payments` | ✅ | Xác nhận thanh toán mock |
| GET | `/api/admin/payments?page=1` | 🔑 | Danh sách payments (phân trang) |
| GET | `/api/admin/payments/stats` | 🔑 | Thống kê doanh thu |
| GET | `/api/admin/refunds?status=pending` | 🔑 | Danh sách refund |
| PATCH | `/api/admin/refunds/:id/approve` | 🔑 | Duyệt hoàn tiền |
| PATCH | `/api/admin/refunds/:id/reject` | 🔑 | Từ chối (kèm lý do) |

## Ràng buộc & Quy tắc nghiệp vụ
- Lịch hẹn `unpaid` quá **15 phút** → cron tự hủy, giảm slot, không tạo refund.
- Mỗi lịch hẹn chỉ có **1 payment** và **1 refund** duy nhất.
- Refund bị rejected → **không thể tạo lại** cho cùng lịch hẹn.
- Admin từ chối refund → `payment_status` giữ nguyên `'paid'` (không reset).
- % hoàn tiền **không hardcode** — lấy từ `payment_settings`.
- Refund `completed` **không thể sửa/xóa**.

## Giao diện cần xây dựng
- Trang thanh toán mock (bệnh nhân) — đơn giản, chỉ xác nhận
- Trang Admin payments (`/admin/payments`) — phân tab: Payments / Refunds
- Cards thống kê doanh thu
- Badge số refund pending trên menu Admin

## Chức năng liên quan
- **A5** — Đặt lịch → tạo payment unpaid
- **B3** — Bác sĩ từ chối → refund 100%
- **C5** — Admin hủy khẩn cấp → refund 100%
