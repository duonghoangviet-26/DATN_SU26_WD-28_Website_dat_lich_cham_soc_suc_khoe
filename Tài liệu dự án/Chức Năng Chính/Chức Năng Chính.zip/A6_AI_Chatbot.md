# A6 — Chatbot tư vấn sức khỏe (AI)

## Mô tả
Trợ lý ảo 24/7 dùng Google Gemini AI. Chỉ trả lời câu hỏi sức khỏe cơ bản tiếng Việt, **không chẩn đoán bệnh, không kê đơn thuốc**. Ưu tiên thấp — implement sau khi hoàn thành các chức năng core.

## Đối tượng sử dụng
| Người dùng | Vai trò |
|---|---|
| Bệnh nhân | Đặt câu hỏi sức khỏe, xem lịch sử hội thoại |

## Luồng nghiệp vụ

### 1. Gửi câu hỏi đến AI
1. Bệnh nhân nhập câu hỏi (tối đa **1000 ký tự** — server validate).
2. Server kiểm tra rate limit: tối đa 20 tin nhắn/phút/user.
3. Lấy 5 tin nhắn gần nhất của session làm context.
4. Gọi Gemini API với **system prompt cố định**:
   > "Bạn là trợ lý sức khỏe cho ứng dụng VitaFamily. Chỉ trả lời các câu hỏi liên quan đến sức khỏe, bệnh tật, thuốc men bằng tiếng Việt. Không chẩn đoán bệnh. Không kê đơn thuốc. Nếu câu hỏi không liên quan đến y tế, từ chối lịch sự và nhắc lại phạm vi hỗ trợ."
5. Lưu câu hỏi + câu trả lời vào `chat_messages`.
6. Trả về kèm disclaimer: *"Thông tin chỉ mang tính tham khảo, không thay thế ý kiến bác sĩ."*
7. Nếu Gemini lỗi/timeout → trả về thông báo: *"Trợ lý đang bận, vui lòng thử lại sau."*

### 2. Bắt đầu session mới
1. Bệnh nhân nhấn "Chat mới" → tạo `chat_sessions` mới.
2. Session cũ không hiển thị trong session mới nhưng vẫn lưu.
3. **Session tự đóng sau 24 giờ không hoạt động** (`chat_sessions.ended_at` = thời điểm tin nhắn cuối + 24h).

### 3. Xem lại lịch sử chat
1. Bệnh nhân xem danh sách sessions cũ.
2. Chọn session → xem toàn bộ nội dung.

### 4. Xoá lịch sử
1. Bệnh nhân xoá session → xoá `chat_sessions` và `chat_messages` liên quan.

## Bảng dữ liệu liên quan
| Bảng | Mục đích |
|---|---|
| `chat_sessions` | Mỗi phiên chat: started_at, ended_at |
| `chat_messages` | Từng tin nhắn: sender_role (user/ai), content, timestamp |

## API Endpoints
| Method | Endpoint | Auth | Mô tả |
|---|---|---|---|
| POST | `/api/chat/message` | ✅ | Gửi tin nhắn, nhận phản hồi AI |
| GET | `/api/chat/sessions` | ✅ | Danh sách sessions |
| GET | `/api/chat/sessions/:id` | ✅ | Nội dung một session |
| DELETE | `/api/chat/sessions/:id` | ✅ | Xoá session |

## Ràng buộc & Quy tắc nghiệp vụ
- Giới hạn tin nhắn: tối đa **1000 ký tự/tin** (server reject nếu vượt).
- Rate limit: tối đa **20 tin nhắn/phút/user**.
- Context: lấy tối đa **5 tin gần nhất** của session để tránh vượt token limit Gemini.
- Chatbot **chỉ trả lời về sức khỏe** — system prompt chặn câu hỏi ngoài phạm vi.
- Luôn kèm disclaimer cố định trong response.
- Session tự đóng sau **24 giờ** không có tin nhắn mới.
- Chỉ nhận **văn bản thuần** — không nhận file hay ảnh.
- Nếu Gemini API lỗi → trả về thông báo thân thiện, **không để app crash**.

## Giao diện cần xây dựng
- Trang chat (`/chat`) — giao diện bong bóng chat
- Danh sách sessions cũ bên trái (desktop)
- Disclaimer cố định phía dưới ô nhập
- Hiển thị trạng thái "đang gõ..." khi chờ Gemini

## Chức năng liên quan
- **A5** — Chatbot gợi ý đặt lịch khi nhận câu hỏi nghiêm trọng
