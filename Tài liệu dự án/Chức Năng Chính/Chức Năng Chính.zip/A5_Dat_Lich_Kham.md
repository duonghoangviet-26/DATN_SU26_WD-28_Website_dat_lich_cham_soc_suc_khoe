# A5 — Đặt lịch khám

## Mô tả
Luồng đặt lịch 6 bước cho bệnh nhân. Có xử lý race condition khi nhiều người đặt cùng slot, timeout tự hủy nếu không thanh toán, và chính sách hoàn tiền khi hủy lịch.

## Đối tượng sử dụng
| Người dùng | Vai trò |
|---|---|
| Bệnh nhân | Đặt lịch, xem danh sách lịch hẹn, hủy lịch |
| Hệ thống | Kiểm tra slot, xử lý race condition, timeout thanh toán |

## Luồng nghiệp vụ

### 1. Đặt lịch (6 bước)
**Bước 1 — Chọn hình thức:** `clinic` (tại viện) / `home` (tại nhà) / `video` (tư vấn).

**Bước 2 — Chọn đối tượng khám:**
- Chọn thành viên trong nhóm gia đình (nếu đã có nhóm).
- Hoặc nhập khách (guest): tên, năm sinh, số điện thoại — **không cần đăng nhập riêng**.

**Bước 3 — Tìm bác sĩ:**
- Lọc theo chuyên khoa và bệnh viện.
- Chỉ hiển thị bác sĩ `approval_status = 'approved'` và `is_visible = true`.

**Bước 4 — Chọn ngày và slot:**
- Xem lịch bác sĩ theo tháng, chọn ngày có slot.
- Chỉ hiển thị slot có `current_patients < max_patients`.
- **Ngày phải từ hôm nay trở đi**, không đặt quá khứ.

**Bước 5 — Nhập lý do khám** (tối đa 500 ký tự).

**Bước 6 — Xác nhận & thanh toán:**
1. Hiển thị tóm tắt, bệnh nhân xác nhận.
2. Server dùng **`SELECT ... FOR UPDATE`** để lock slot trước khi kiểm tra và tăng `current_patients`.
3. Tạo `appointments` với `status = 'pending'`, `payment_status = 'unpaid'`.
4. Chuyển sang trang thanh toán mock.
5. Bệnh nhân nhấn "Thanh toán" → `payment_status = 'paid'`, tạo `payments`.
6. **Nếu bệnh nhân đóng tab mà không thanh toán:** cron chạy mỗi 15 phút kiểm tra appointment `unpaid` quá 15 phút → tự hủy, giảm `current_patients`, không tạo refund.
7. Gửi email xác nhận sau khi thanh toán xong.

### 2. Ràng buộc khi đặt lịch
- **Cùng ngày, cùng bác sĩ:** Bệnh nhân không thể đặt 2 lịch hẹn với cùng một bác sĩ trong cùng ngày.
- **Cùng slot:** Mỗi slot giới hạn `max_patients` — sử dụng DB lock tránh đặt quá số chỗ.

### 3. Xem danh sách lịch hẹn của bệnh nhân
1. Vào trang "Lịch hẹn của tôi".
2. Phân tab: Sắp tới / Chờ xác nhận / Đã hoàn thành / Đã hủy.
3. Xem chi tiết: bác sĩ, ngày giờ, hình thức, trạng thái, thanh toán.

### 4. Hủy lịch hẹn
1. Chỉ hủy được lịch `pending` hoặc `confirmed`, có `payment_status = 'paid'`.
2. Nếu `payment_status = 'unpaid'` → hủy ngay, không tạo refund.
3. Nếu đã thanh toán → tính % hoàn tiền dựa trên **thời gian từ lúc hủy đến lúc khám**.
4. Cập nhật: `appointment.status = 'cancelled'`, giảm `slot.current_patients`, tạo `refunds` (nếu có).
5. Gửi email thông báo hủy lịch.

## Chính sách hoàn tiền (đã thanh toán)
| Thời gian còn lại trước lịch khám | % Được hoàn |
|---|---|
| ≥ 24 giờ | 100% |
| 12 – 24 giờ | 80% |
| 6 – 12 giờ | 50% |
| < 6 giờ | 0% |
| Bác sĩ từ chối (B3) | 100% bất kể thời gian |
| Admin hủy khẩn cấp (C5) | 100% bất kể thời gian |

## Vòng đời trạng thái
```
pending (unpaid) → [timeout 15 phút] → cancelled (tự động, không refund)
pending (paid)   → confirmed → completed
pending (paid)   → cancelled (bệnh nhân hủy, có refund)
confirmed        → cancelled (bệnh nhân hủy, có refund)
confirmed        → completed
```

## Vòng đời slot.current_patients
```
Đặt lịch thành công (paid)  → +1
Hủy lịch (bất kỳ lý do)     → -1
Timeout unpaid               → -1
Bác sĩ từ chối (B3)          → -1  ← phải xử lý ở B3
Admin hủy (C5)               → -1  ← phải xử lý ở C5
```

## Bảng dữ liệu liên quan
| Bảng | Mục đích |
|---|---|
| `appointments` | Lịch hẹn: status, payment_status, member_id (nullable cho guest) |
| `slots` | current_patients tăng/giảm, dùng SELECT FOR UPDATE |
| `payments` | Ghi nhận thanh toán mock |
| `refunds` | Hoàn tiền khi hủy (chỉ khi đã thanh toán) |

## API Endpoints
| Method | Endpoint | Auth | Mô tả |
|---|---|---|---|
| GET | `/api/doctors` | ❌ | Danh sách bác sĩ (filter) |
| GET | `/api/doctors/:id` | ❌ | Chi tiết bác sĩ (public) |
| GET | `/api/doctors/:id/available-slots` | ✅ | Slots còn trống theo ngày |
| POST | `/api/appointments` | ✅ | Tạo lịch hẹn (status=pending, unpaid) |
| POST | `/api/payments` | ✅ | Xác nhận thanh toán mock |
| GET | `/api/appointments/my` | ✅ | Lịch hẹn của bệnh nhân |
| GET | `/api/appointments/:id` | ✅ | Chi tiết lịch hẹn |
| POST | `/api/appointments/:id/cancel` | ✅ | Hủy lịch hẹn |

## Ràng buộc & Quy tắc nghiệp vụ
- Không đặt lịch ngày **quá khứ**.
- Slot dùng **`SELECT ... FOR UPDATE`** khi tăng `current_patients`.
- **Không đặt 2 lịch** cùng bác sĩ cùng ngày.
- Lịch `unpaid` quá 15 phút → cron **tự hủy**, giảm slot, không tạo refund.
- Lịch `completed` **không thể hủy**.
- Guest appointment: `member_id = NULL` trong `appointments` là hợp lệ.

## Giao diện cần xây dựng
- Wizard đặt lịch 6 bước (`/booking`) — progress bar
- Trang danh sách lịch hẹn (`/appointments`) — phân tab
- Trang chi tiết lịch hẹn — nút Hủy (nếu đủ điều kiện), nút Đánh giá (nếu completed)
- Trang thanh toán mock — đơn giản, chỉ bấm xác nhận

## Chức năng liên quan
- **A2** — Chọn thành viên khi đặt lịch
- **B2** — Slot do bác sĩ tạo
- **B3** — Bác sĩ xác nhận/từ chối → slot.current_patients thay đổi
- **C5** — Admin hủy khẩn cấp → slot.current_patients giảm
- **C8** — Thanh toán và refund
- **A7** — Thông báo khi trạng thái thay đổi
