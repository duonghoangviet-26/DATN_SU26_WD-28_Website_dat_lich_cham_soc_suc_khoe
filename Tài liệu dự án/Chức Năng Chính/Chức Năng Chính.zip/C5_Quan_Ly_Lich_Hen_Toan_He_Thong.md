# C5 — Quản lý lịch hẹn toàn hệ thống

## Mô tả
Admin xem toàn cảnh mọi lịch hẹn trong hệ thống. Khi hủy lịch khẩn cấp, slot.current_patients tự giảm và hoàn tiền 100%.

## Đối tượng sử dụng
| Người dùng | Vai trò |
|---|---|
| Admin | Xem tổng quan, lọc, tìm kiếm, hủy lịch hẹn khẩn cấp |

## Luồng nghiệp vụ

### 1. Xem tổng quan (cards thống kê)
1. Admin vào `/admin/appointments`.
2. Cards hiển thị nhanh: tổng hôm nay, số pending, số confirmed, số hủy tuần này.

### 2. Xem danh sách (có phân trang)
1. Bảng phân trang (20 lịch/trang).
2. Lọc theo: trạng thái, ngày khám, bác sĩ (tìm theo tên), hình thức.
3. Sắp xếp theo ngày khám — mặc định gần nhất trước.

### 3. Hủy lịch hẹn khẩn cấp
1. Admin nhấn "Hủy" trên lịch `pending` hoặc `confirmed`.
2. **Bắt buộc** nhập lý do.
3. Trong cùng **1 transaction**:
   - `appointment.status = 'cancelled'`, lưu lý do.
   - **Giảm `slot.current_patients` đi 1.**
   - Nếu `payment_status = 'paid'` → tạo `refunds` 100%.
4. Gửi thông báo + email cho cả **bệnh nhân và bác sĩ**.
5. Ghi `audit_logs`.

## Bảng dữ liệu liên quan
| Bảng | Mục đích |
|---|---|
| `appointments` | Dữ liệu lịch hẹn |
| `slots` | **Giảm current_patients khi hủy** |
| `refunds` | Tạo refund 100% nếu đã thanh toán |
| `audit_logs` | Ghi lại mọi thao tác hủy |

## API Endpoints
| Method | Endpoint | Auth | Mô tả |
|---|---|---|---|
| GET | `/api/admin/appointments?page=1&status=pending` | 🔑 | Danh sách có phân trang, lọc |
| GET | `/api/admin/appointments/stats` | 🔑 | Cards thống kê nhanh |
| GET | `/api/admin/appointments/:id` | 🔑 | Chi tiết lịch hẹn |
| PATCH | `/api/admin/appointments/:id/cancel` | 🔑 | Hủy khẩn cấp (giảm slot + tạo refund) |

## Ràng buộc & Quy tắc nghiệp vụ
- Hủy **bắt buộc** nhập lý do.
- Hủy → **`slot.current_patients - 1`** trong cùng transaction.
- Admin hủy → hoàn tiền **100%** nếu đã thanh toán.
- Chỉ hủy được lịch `pending` hoặc `confirmed`.
- Lịch `completed` **không thể hủy**.
- Mọi thao tác ghi `audit_logs`.
- API có **phân trang** (20 lịch/trang).

## Giao diện cần xây dựng
- Bảng lịch hẹn có phân trang và bộ lọc
- Cards thống kê phía trên
- Modal chi tiết lịch hẹn
- Dialog hủy: ô nhập lý do bắt buộc

## Chức năng liên quan
- **A5** — Bệnh nhân đặt lịch → xuất hiện ở đây
- **C8** — Hủy tạo refund
- **C1** — Sau khi khoá bác sĩ, Admin vào đây xử lý lịch còn lại
