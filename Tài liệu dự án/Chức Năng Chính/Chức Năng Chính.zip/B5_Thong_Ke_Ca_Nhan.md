# B5 — Xem thống kê cá nhân & đánh giá

## Mô tả
Dashboard hiệu suất của bác sĩ: số ca khám, biểu đồ theo thời gian, rating trung bình và danh sách đánh giá. Nếu chưa có dữ liệu, hiển thị empty state thân thiện.

## Đối tượng sử dụng
| Người dùng | Vai trò |
|---|---|
| Bác sĩ | Xem thống kê cá nhân và đánh giá từ bệnh nhân |

## Luồng nghiệp vụ

### 1. Xem tổng quan thống kê
1. Bác sĩ vào `/doctor/dashboard`.
2. Mặc định hiển thị dữ liệu tháng hiện tại.
3. Bác sĩ chọn khoảng thời gian: tuần / tháng / 3 tháng / tùy chọn ngày.
4. Các chỉ số:
   - Tổng số ca `completed` (so sánh % với kỳ trước).
   - Số ca bị hủy.
   - Tỉ lệ xác nhận đúng hạn (xem định nghĩa bên dưới).
5. Biểu đồ đường: số ca `completed` theo ngày.
6. Biểu đồ tròn: phân bổ trạng thái.
7. **Empty state:** Nếu chưa có ca nào → hiển thị card hướng dẫn *"Hãy tạo lịch làm việc để bắt đầu nhận bệnh nhân"*.

### 2. Xem đánh giá từ bệnh nhân
1. Rating trung bình từ tất cả reviews có `status = 'visible'`.
2. Biểu đồ cột phân bổ 1–5 sao.
3. Danh sách đánh giá — **chỉ hiển thị `status = 'visible'`**.
4. Đánh giá bị Admin ẩn (`status = 'hidden'`) → **bác sĩ không thấy** — đồng bộ với C6.
5. Nếu chưa có đánh giá → empty state *"Chưa có đánh giá nào"*.

## Định nghĩa "Tỉ lệ xác nhận đúng hạn"
```
= (Số lịch pending → confirmed trong vòng 12h) / Tổng lịch pending × 100%
```
Lịch tự hủy sau 48h (B3) và lịch bị từ chối đều tính là **không đúng hạn**.

## Bảng dữ liệu liên quan
| Bảng | Mục đích |
|---|---|
| `appointments` | Thống kê số ca, trạng thái, thời gian xác nhận |
| `reviews` | Đánh giá có status = 'visible' |

## API Endpoints
| Method | Endpoint | Auth | Mô tả |
|---|---|---|---|
| GET | `/api/doctors/:id/stats?from=2026-06-01&to=2026-06-30` | 👨‍⚕️ | Thống kê theo khoảng thời gian |
| GET | `/api/doctors/:id/reviews?page=1` | ❌ | Đánh giá công khai (visible), có phân trang |

## Ràng buộc & Quy tắc nghiệp vụ
- Chỉ hiển thị đánh giá `status = 'visible'`. Đánh giá Admin ẩn **bác sĩ không thấy**.
- Rating trung bình tính lại ngay khi Admin ẩn/xóa đánh giá (C6 trigger).
- Bác sĩ chỉ xem thống kê **của chính mình**.
- API stats nhận query param `from` và `to` (YYYY-MM-DD) — không cứng tháng hiện tại.
- Empty state phải thân thiện, không hiển thị trang trắng.

## Giao diện cần xây dựng
- Dashboard bác sĩ (`/doctor/dashboard`)
- Bộ lọc khoảng thời gian: dropdown + datepicker tùy chọn
- Cards chỉ số nhanh (có skeleton loading)
- Biểu đồ đường số ca (recharts/chart.js)
- Danh sách đánh giá dạng card có phân trang
- Empty state cards khi không có dữ liệu

## Chức năng liên quan
- **B3** — Ca hoàn thành → tính vào thống kê
- **C6** — Admin ẩn đánh giá → cập nhật ngay rating trung bình
