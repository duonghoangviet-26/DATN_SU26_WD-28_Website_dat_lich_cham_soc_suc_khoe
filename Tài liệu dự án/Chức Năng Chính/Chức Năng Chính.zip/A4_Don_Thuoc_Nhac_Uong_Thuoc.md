# A4 — Quản lý đơn thuốc & nhắc uống thuốc

## Mô tả
Chuyển đơn thuốc thành lịch nhắc uống thuốc tự động qua email. Đơn có thể do bác sĩ kê hoặc bệnh nhân tự nhập. Reminder có đủ 4 trạng thái: pending / sent / taken / missed.

## Đối tượng sử dụng
| Người dùng | Vai trò |
|---|---|
| Bệnh nhân | Xem đơn thuốc, tự nhập đơn, đánh dấu đã uống, điều chỉnh giờ nhắc |
| Bác sĩ | Kê đơn thuốc sau ca khám (B4) |
| Hệ thống (node-cron) | Gửi email nhắc mỗi 5 phút và đánh dấu missed |

## Luồng nghiệp vụ

### 1. Bệnh nhân tự nhập đơn thuốc
1. Bệnh nhân chọn thành viên cần theo dõi thuốc, nhấn "Thêm đơn thuốc".
2. Nhập: tên thuốc, liều lượng, tần suất, chọn khung giờ (Sáng/Trưa/Chiều/Tối), ngày bắt đầu, ngày kết thúc.
3. Hệ thống tạo `prescriptions` (với `medical_record_id = NULL` — hợp lệ cho đơn tự nhập), `prescription_items`.
4. Tạo `reminders`: **tối đa 90 ngày × số lần/ngày** — nếu `end_date - start_date > 90 ngày`, từ chối và yêu cầu chia nhỏ đơn.

### 2. Nhắc nhở tự động (node-cron mỗi 5 phút)
**Gửi nhắc (pending → sent):**
1. Lấy reminders có `status = 'pending'` và `remind_time <= NOW()`.
2. Gửi email nhắc đến `users.email`.
3. Cập nhật `status = 'sent'`, `sent_at = NOW()`.

**Đánh dấu missed:**
1. Lấy reminders có `status = 'sent'` và `sent_at < NOW() - 2 giờ` (đã gửi nhắc nhưng quá 2 tiếng chưa xác nhận).
2. Cập nhật `status = 'missed'`.

### 3. Đánh dấu đã uống thuốc
1. Bệnh nhân xem danh sách nhắc nhở hôm nay trên Dashboard.
2. Nhấn "Đã uống" → `status = 'taken'`.
3. Chỉ reminder có `status = 'sent'` mới cho đánh dấu taken. Reminder `missed` không thể undo.

### 4. Điều chỉnh giờ nhắc (chỉ đơn tự nhập)
1. Bệnh nhân chọn đơn thuốc do mình tự tạo (`source = 'self'`).
2. Sửa giờ uống của `prescription_items`.
3. Hệ thống xoá reminders cũ `pending` chưa gửi và tạo lại với giờ mới.
4. Đơn thuốc do bác sĩ kê (`source = 'doctor'`) **không được sửa** nội dung thuốc, nhưng bệnh nhân có thể sửa giờ nhắc.

## Trạng thái reminder
```
pending → sent      (cron gửi email)
sent → taken        (bệnh nhân xác nhận)
sent → missed       (cron đánh dấu sau 2 tiếng không xác nhận)
```

## Bảng dữ liệu liên quan
| Bảng | Mục đích |
|---|---|
| `prescriptions` | Đơn thuốc, liên kết `member_id` (bắt buộc) và `medical_record_id` (nullable) |
| `prescription_items` | Chi tiết từng loại thuốc, time_slots (JSON), start/end date |
| `reminders` | Từng lần nhắc: remind_time, status (pending/sent/taken/missed) |

## API Endpoints
| Method | Endpoint | Auth | Mô tả |
|---|---|---|---|
| GET | `/api/prescriptions` | ✅ | Danh sách đơn thuốc (lọc theo member) |
| POST | `/api/prescriptions` | ✅ | Tạo đơn thuốc mới (tự nhập) |
| GET | `/api/prescriptions/:id` | ✅ | Chi tiết một đơn |
| PUT | `/api/prescriptions/:id/schedule` | ✅ | Sửa giờ nhắc (chỉ đơn tự nhập) |
| DELETE | `/api/prescriptions/:id` | ✅ | Xoá đơn (chỉ đơn tự nhập, source='self') |
| GET | `/api/reminders/today` | ✅ | Nhắc nhở hôm nay |
| PATCH | `/api/reminders/:id/taken` | ✅ | Đánh dấu đã uống (chỉ status='sent') |

## Ràng buộc & Quy tắc nghiệp vụ
- `end_date >= start_date`, khoảng cách tối đa **90 ngày**.
- Đơn bác sĩ (`source = 'doctor'`) không xoá được, không sửa thuốc, chỉ sửa giờ nhắc.
- Reminder `missed` và `taken` không gửi lại.
- Khi xoá thành viên (soft delete A2) → reminder của thành viên đó tự **pause** (không gửi nữa).
- Chỉ gửi email (không FCM). Nếu `users.email` trống → bỏ qua, không báo lỗi.
- Mỗi đơn thuốc phải có `member_id` rõ ràng.

## Giao diện cần xây dựng
- Trang đơn thuốc (`/prescriptions`) — lọc theo thành viên, hiển thị tiến độ
- Widget "Nhắc hôm nay" trên Dashboard — phân loại pending/sent/taken/missed
- Modal thêm đơn tự nhập, modal sửa giờ nhắc
- Màu sắc phân biệt: xanh = taken, vàng = sent (chờ xác nhận), xám = missed, trắng = pending

## Chức năng liên quan
- **A3** — Đơn thuốc liên kết hồ sơ khám
- **B4** — Bác sĩ kê đơn → hệ thống tạo reminders tự động
- **A7** — Thông báo nhắc thuốc trong danh sách A7
