# C4 — Quản lý dịch vụ

## Mô tả
Admin quản lý gói dịch vụ khám (đặc biệt là khám tại nhà). Dịch vụ là **tùy chọn** khi đặt lịch. Giá dịch vụ đóng băng tại thời điểm đặt lịch, thay đổi giá sau không ảnh hưởng lịch cũ.

## Đối tượng sử dụng
| Người dùng | Vai trò |
|---|---|
| Admin | Tạo, sửa, bật/tắt, xóa dịch vụ |
| Bệnh nhân | Chọn dịch vụ (tùy chọn) khi đặt lịch hình thức `home` |

## Luồng nghiệp vụ

### 1. Thêm dịch vụ mới
1. Admin điền: tên, mô tả, giá tiền (> 0), thời gian thực hiện (phút), chuyên khoa liên quan (tùy chọn).
2. Lưu với `status = 'active'`.

### 2. Sửa dịch vụ
1. Sửa thông tin.
2. **Thay đổi giá không ảnh hưởng lịch hẹn cũ** — giá lịch hẹn được lưu tại thời điểm đặt (`appointments.price_snapshot`).

### 3. Bật/tắt dịch vụ
1. Toggle trạng thái.
2. Dịch vụ `inactive` → không hiển thị khi đặt lịch mới.
3. Lịch hẹn cũ đã dùng dịch vụ `inactive` vẫn còn hiệu lực.

### 4. Xóa dịch vụ
1. Kiểm tra không có lịch hẹn `pending`/`confirmed` đang dùng dịch vụ này.
2. Nếu có → từ chối, gợi ý tắt dịch vụ thay vì xóa.

## Bảng dữ liệu liên quan
| Bảng | Mục đích |
|---|---|
| `services` | Tên, giá, mô tả, trạng thái |
| `appointments` | Có field `service_id` (nullable) và `price_snapshot` |

## API Endpoints
| Method | Endpoint | Auth | Mô tả |
|---|---|---|---|
| GET | `/api/services` | ❌ | Danh sách dịch vụ active (public) |
| POST | `/api/services` | 🔑 | Thêm dịch vụ |
| PUT | `/api/services/:id` | 🔑 | Sửa dịch vụ |
| PATCH | `/api/services/:id/status` | 🔑 | Bật/tắt |
| DELETE | `/api/services/:id` | 🔑 | Xóa (kiểm tra lịch active) |

## Ràng buộc & Quy tắc nghiệp vụ
- Dịch vụ là **tùy chọn** khi đặt lịch `home` — bệnh nhân có thể không chọn.
- Dịch vụ `inactive` không hiển thị khi đặt lịch mới, nhưng lịch cũ không bị ảnh hưởng.
- Thay đổi giá dịch vụ **không ảnh hưởng** lịch hẹn đã đặt (giá đã được snapshot).
- Giá tiền phải > 0.

## Giao diện cần xây dựng
- Trang dịch vụ (`/admin/services`) — bảng + toggle inline
- Modal thêm/sửa dịch vụ

## Chức năng liên quan
- **A5** — Bệnh nhân chọn dịch vụ (tùy chọn) khi đặt lịch home
- **C3** — Dịch vụ có thể gắn với chuyên khoa
