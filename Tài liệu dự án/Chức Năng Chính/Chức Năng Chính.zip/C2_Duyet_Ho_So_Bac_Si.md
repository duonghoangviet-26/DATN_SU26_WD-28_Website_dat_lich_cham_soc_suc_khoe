# C2 — Duyệt hồ sơ bác sĩ

## Mô tả
Admin thẩm định hồ sơ chuyên môn bác sĩ. Khi duyệt → role đổi thành 'doctor'. Admin cũng có thể đình chỉ bác sĩ đã được duyệt khi cần.

## Đối tượng sử dụng
| Người dùng | Vai trò |
|---|---|
| Admin | Duyệt, từ chối, đình chỉ hồ sơ bác sĩ |
| Bác sĩ | Nhận kết quả qua email, cập nhật nếu bị từ chối |

## Luồng nghiệp vụ

### 1. Xem danh sách hồ sơ
1. Admin thấy badge số `pending` trên menu.
2. Vào `/admin/doctors`, lọc theo: Chờ duyệt / Đã duyệt / Từ chối / Đình chỉ.
3. Ưu tiên hồ sơ `pending` lên đầu.

### 2. Duyệt hồ sơ
1. Admin xem chi tiết hồ sơ.
2. Nhấn "Duyệt" → trong cùng **1 transaction**:
   - `doctors.approval_status = 'approved'`.
   - `users.role = 'doctor'`.
3. Gửi email chúc mừng.
4. Ghi `audit_logs`.

### 3. Từ chối hồ sơ
1. Admin nhấn "Từ chối", **bắt buộc** nhập lý do.
2. `doctors.approval_status = 'rejected'`, lưu `rejection_reason`.
3. `users.role` giữ nguyên `'user'`.
4. Gửi email kèm lý do và hướng dẫn cập nhật.
5. Ghi `audit_logs`.

### 4. Đình chỉ bác sĩ đã được duyệt
1. Admin nhấn "Đình chỉ" trên hồ sơ `approved`.
2. **Bắt buộc** nhập lý do và thời gian đình chỉ (nếu tạm thời) hoặc không giới hạn.
3. `doctors.approval_status = 'suspended'`, `is_visible = false`.
4. Bác sĩ biến khỏi tìm kiếm, không nhận lịch hẹn mới.
5. Lịch hẹn cũ đang `pending`/`confirmed` → Admin cần xử lý thủ công (C5).
6. Gửi email thông báo đình chỉ.
7. Ghi `audit_logs`.

### 5. Khôi phục bác sĩ bị đình chỉ
1. Admin nhấn "Khôi phục" → `approval_status = 'approved'`, `is_visible = true`.
2. Gửi email thông báo.

## Trạng thái hồ sơ bác sĩ
```
pending   → approved   (Admin duyệt → users.role = 'doctor')
pending   → rejected   (Admin từ chối, kèm lý do)
rejected  → pending    (Bác sĩ nộp lại, tối đa 5 lần)
approved  → suspended  (Admin đình chỉ)
suspended → approved   (Admin khôi phục)
```

## Bảng dữ liệu liên quan
| Bảng | Mục đích |
|---|---|
| `doctors` | approval_status, rejection_reason, submit_count |
| `users` | role đổi thành 'doctor' khi được duyệt |
| `audit_logs` | Ghi mọi thao tác |

## API Endpoints
| Method | Endpoint | Auth | Mô tả |
|---|---|---|---|
| GET | `/api/admin/doctors?status=pending` | 🔑 | Danh sách hồ sơ (lọc) |
| GET | `/api/admin/doctors/:id` | 🔑 | Chi tiết hồ sơ |
| PATCH | `/api/admin/doctors/:id/approve` | 🔑 | Duyệt (đổi role + status) |
| PATCH | `/api/admin/doctors/:id/reject` | 🔑 | Từ chối (kèm lý do) |
| PATCH | `/api/admin/doctors/:id/suspend` | 🔑 | Đình chỉ bác sĩ đã duyệt |
| PATCH | `/api/admin/doctors/:id/restore` | 🔑 | Khôi phục bác sĩ bị đình chỉ |

## Ràng buộc & Quy tắc nghiệp vụ
- Từ chối và đình chỉ **bắt buộc** nhập lý do.
- Duyệt hồ sơ → `users.role = 'doctor'` trong **cùng 1 transaction** (atomic).
- Bác sĩ bị từ chối có thể nộp lại, tối đa **5 lần** (sau đó liên hệ Admin trực tiếp).
- Đình chỉ → bác sĩ biến khỏi tìm kiếm, lịch cũ không bị xóa.
- Mọi thao tác ghi `audit_logs`.

## Giao diện cần xây dựng
- Trang duyệt bác sĩ (`/admin/doctors`) — badge pending
- Trang chi tiết hồ sơ — đầy đủ thông tin chuyên môn
- Nút Duyệt / Từ chối / Đình chỉ rõ ràng theo trạng thái
- Dialog nhập lý do (bắt buộc với từ chối và đình chỉ)

## Chức năng liên quan
- **B1** — Bác sĩ tạo hồ sơ ở B1
- **A1** — role đổi thành 'doctor' khi duyệt
- **C5** — Sau khi đình chỉ, xử lý lịch hẹn còn lại
