# A7 — Xem thông báo

## Mô tả
Trung tâm thông báo của người dùng. Tập hợp tất cả thông báo về lịch hẹn, thuốc, kết quả khám và thông báo hệ thống. Mỗi thông báo có `related_id` và `related_type` để điều hướng đúng trang.

## Đối tượng sử dụng
| Người dùng | Vai trò |
|---|---|
| Bệnh nhân | Nhận thông báo lịch hẹn, nhắc thuốc, kết quả khám |
| Bác sĩ | Nhận thông báo lịch hẹn mới |

## Nguồn tạo ra thông báo
| Sự kiện | Người nhận | Loại | related_type | Điều hướng |
|---|---|---|---|---|
| Bác sĩ xác nhận lịch hẹn | Bệnh nhân | appointment | appointment | /appointments/:id |
| Bác sĩ từ chối lịch hẹn (kèm lý do) | Bệnh nhân | appointment | appointment | /appointments/:id |
| Bệnh nhân đặt lịch mới | Bác sĩ | appointment | appointment | /doctor/appointments/:id |
| **1 ngày trước lịch khám** (cron 8h sáng) | Bệnh nhân | appointment | appointment | /appointments/:id |
| Bác sĩ hoàn thành ca khám | Bệnh nhân | appointment | medical_record | /medical-records/:id |
| Đến giờ uống thuốc (cron mỗi 5 phút) | Bệnh nhân | medicine | reminder | /prescriptions/:id |
| Admin gửi thủ công (C7) | Nhóm được chọn | system | null | url từ C7 (tùy chọn) |

## Luồng nghiệp vụ

### 1. Xem danh sách thông báo
1. Người dùng nhấn icon chuông trên navbar.
2. Hệ thống trả về danh sách thông báo theo trang (20 thông báo/trang), mới nhất trước.
3. Thông báo chưa đọc (`is_read = false`) hiển thị nổi bật hơn.

### 2. Đánh dấu đã đọc & điều hướng
1. Người dùng nhấn vào thông báo → tự động `is_read = true`.
2. Hệ thống đọc `related_type` và `related_id` để điều hướng đến đúng trang.
3. Nếu `related_id` không còn tồn tại (đã bị xoá) → chỉ đánh dấu đã đọc, không điều hướng.

### 3. Đánh dấu tất cả đã đọc
1. Nhấn "Đánh dấu tất cả đã đọc" → cập nhật toàn bộ `is_read = true` cho user đó.

### 4. Badge unread count
1. Khi trang tải → gọi API lấy `unread_count`.
2. Hiển thị trên icon chuông, tối đa "99+".
3. Tự cập nhật sau mỗi hành động đánh dấu đã đọc.

### 5. Cron nhắc lịch khám (ngày hôm sau)
1. Cron chạy **mỗi ngày lúc 8:00 sáng**.
2. Tìm tất cả lịch hẹn `confirmed` vào **ngày mai**.
3. Tạo `notifications` loại `appointment` cho từng bệnh nhân.
4. Gửi email nhắc lịch.

### 6. Cleanup thông báo cũ
1. Cron chạy **mỗi tuần**, xoá `notifications` có `created_at < NOW() - 90 ngày`.
2. Chỉ xoá thông báo đã đọc (`is_read = true`) — giữ lại thông báo chưa đọc bất kể bao lâu.

## Bảng dữ liệu liên quan
| Bảng | Mục đích |
|---|---|
| `notifications` | Thông báo cá nhân: is_read, type, related_id, related_type |
| `system_notifications` | Thông báo hệ thống Admin tạo (C7) |

## API Endpoints
| Method | Endpoint | Auth | Mô tả |
|---|---|---|---|
| GET | `/api/notifications?page=1&limit=20` | ✅ | Danh sách thông báo (phân trang) |
| GET | `/api/notifications/unread-count` | ✅ | Số thông báo chưa đọc |
| PATCH | `/api/notifications/:id/read` | ✅ | Đánh dấu 1 thông báo đã đọc |
| PATCH | `/api/notifications/read-all` | ✅ | Đánh dấu tất cả đã đọc |

## Ràng buộc & Quy tắc nghiệp vụ
- Thông báo **không thể xoá** bởi user — chỉ đánh dấu đã đọc.
- Hệ thống tự cleanup thông báo đã đọc > **90 ngày**.
- Mỗi thông báo có `related_id` + `related_type` để biết điều hướng đến đâu.
- API có **phân trang** (20 thông báo/trang) để tránh trả về quá nhiều dữ liệu.
- Badge tối đa hiển thị **"99+"**.
- Cron nhắc lịch khám chạy mỗi ngày lúc **8:00 sáng** — là cron job **riêng biệt** với cron nhắc thuốc.

## Giao diện cần xây dựng
- Icon chuông trên navbar + badge unread count
- Dropdown hoặc trang `/notifications` hiển thị danh sách có phân trang
- Phân loại bằng icon/màu: 💊 medicine / 📅 appointment / 📢 system
- Click vào thông báo → đánh dấu đọc + điều hướng

## Chức năng liên quan
- **A4** — Cron nhắc thuốc tạo thông báo loại `medicine`
- **A5** — Thay đổi trạng thái lịch hẹn tạo thông báo
- **B3** — Xác nhận/từ chối → tạo thông báo cho bệnh nhân
- **C7** — Admin gửi thông báo hệ thống hàng loạt
