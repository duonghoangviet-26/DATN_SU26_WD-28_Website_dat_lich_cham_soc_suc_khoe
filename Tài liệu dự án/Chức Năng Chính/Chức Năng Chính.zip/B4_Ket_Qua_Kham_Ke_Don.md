# B4 — Ghi kết quả khám & kê đơn thuốc

## Mô tả
Sau khi ca khám hoàn thành, bác sĩ ghi chẩn đoán và kê đơn thuốc. Hệ thống tự tạo hồ sơ y tế và reminders cho bệnh nhân. Ghi kết quả là tùy chọn, có thể thực hiện trong vòng 24h sau khi hoàn thành.

## Đối tượng sử dụng
| Người dùng | Vai trò |
|---|---|
| Bác sĩ | Ghi kết quả, kê đơn thuốc (tối đa 10 loại) |
| Hệ thống | Tự động tạo hồ sơ y tế và reminders |

## Luồng nghiệp vụ

### 1. Ghi kết quả khám
1. Bác sĩ vào form ghi kết quả sau khi nhấn "Ghi kết quả" từ B3 (hoặc trong 24h sau completed).
2. Điền: chẩn đoán chính (bắt buộc), hướng dẫn điều trị / ghi chú, ngày tái khám (tùy chọn).
3. Lưu → tạo `examination_results`.

### 2. Kê đơn thuốc (tùy chọn, tối đa 10 loại)
1. Bác sĩ nhấn "Thêm thuốc" — **tối đa 10 loại thuốc** mỗi đơn.
2. Với mỗi thuốc: tên, liều lượng, tần suất, khung giờ (Sáng/Trưa/Chiều/Tối), ngày bắt đầu, ngày kết thúc.
3. Khoảng cách start_date đến end_date **tối đa 90 ngày** (đồng bộ với giới hạn A4).

### 3. Hệ thống xử lý sau khi lưu
1. Tạo `medical_records`:
   - Nếu lịch hẹn có `member_id` → `medical_records.member_id = member_id`.
   - Nếu là khách (guest) → `medical_records.member_id = NULL`, lưu `guest_name`.
2. Tạo `prescriptions` + `prescription_items` (nếu có đơn thuốc).
3. Tạo `reminders` cho từng lần uống.
4. Gửi thông báo cho bệnh nhân.

### 4. Sửa kết quả sau khi lưu
1. Bác sĩ được phép sửa kết quả trong **24 giờ** kể từ lúc lưu lần đầu.
2. Sau 24 giờ → kết quả bị **khóa**, không sửa được.
3. Khi sửa: nếu đơn thuốc thay đổi → **xóa reminders cũ chưa gửi** và tạo lại.

## Chuỗi dữ liệu sau khi lưu
```
appointment (completed)
  └── examination_results  (chẩn đoán, ghi chú, ngày tái khám)
  └── medical_records      (member_id nullable — guest ok)
       └── prescriptions
            └── prescription_items (tối đa 10 loại)
                 └── reminders  (cron gửi nhắc — A4)
```

## Bảng dữ liệu liên quan
| Bảng | Mục đích |
|---|---|
| `examination_results` | Kết quả khám (1 lịch hẹn 1 bản ghi, có thể sửa trong 24h) |
| `medical_records` | Hồ sơ khám, `member_id` nullable (guest hợp lệ) |
| `prescriptions` | Đơn thuốc (có `source = 'doctor'`) |
| `prescription_items` | Tối đa 10 loại, tối đa 90 ngày |
| `reminders` | Lịch nhắc uống thuốc |

## API Endpoints
| Method | Endpoint | Auth | Mô tả |
|---|---|---|---|
| POST | `/api/appointments/:id/examination-result` | 👨‍⚕️ | Ghi kết quả + kê đơn lần đầu |
| PUT | `/api/appointments/:id/examination-result` | 👨‍⚕️ | Sửa kết quả (trong 24h) |
| GET | `/api/appointments/:id/examination-result` | 👨‍⚕️ | Xem lại kết quả đã ghi |

## Ràng buộc & Quy tắc nghiệp vụ
- Chỉ ghi kết quả khi `appointment.status = 'completed'`.
- Mỗi lịch hẹn chỉ có **1 bản ghi** `examination_results`.
- Có thể ghi và sửa trong **24 giờ** sau khi lưu lần đầu.
- Chẩn đoán là trường **bắt buộc** — không để trống.
- `medical_records.member_id` là **nullable** (guest appointment hợp lệ).
- Tối đa **10 loại thuốc** mỗi đơn.
- Mỗi đơn thuốc tối đa **90 ngày** (`end_date - start_date <= 90`).
- Khi sửa đơn thuốc → xóa reminders `pending` chưa gửi, tạo lại.
- Không bắt buộc ghi kết quả — bác sĩ có thể không kê đơn nếu không cần.

## Giao diện cần xây dựng
- Form ghi kết quả (mở từ B3 hoặc từ lịch sử lịch hẹn)
- Section kê đơn — dynamic form thêm/xoá thuốc (tối đa 10)
- Đồng hồ đếm ngược 24h hiển thị khi kết quả có thể sửa
- Sau 24h: hiển thị trạng thái "Đã khoá" — chỉ đọc

## Chức năng liên quan
- **B3** — Chuyển sang B4 sau khi hoàn thành
- **A3** — Hồ sơ tự động xuất hiện phía bệnh nhân
- **A4** — Reminders được tạo từ đơn thuốc
- **A7** — Bệnh nhân nhận thông báo kết quả sẵn sàng
