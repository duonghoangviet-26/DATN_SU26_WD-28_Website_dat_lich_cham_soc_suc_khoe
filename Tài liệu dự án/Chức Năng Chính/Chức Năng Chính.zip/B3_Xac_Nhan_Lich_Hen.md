# B3 — Xác nhận & quản lý lịch hẹn

## Mô tả
Bác sĩ xử lý danh sách lịch hẹn: xác nhận, từ chối hoặc hoàn thành. Khi từ chối → slot.current_patients giảm. Lịch hẹn pending không xác nhận sau 48h tự hủy.

## Đối tượng sử dụng
| Người dùng | Vai trò |
|---|---|
| Bác sĩ | Xem, xác nhận, từ chối, hoàn thành lịch hẹn |

## Luồng nghiệp vụ

### 1. Xem danh sách lịch hẹn
1. Bác sĩ vào `/doctor/appointments`.
2. Phân tab: Chờ xác nhận / Hôm nay / Sắp tới / Lịch sử.
3. Ưu tiên hiển thị tab "Chờ xác nhận" đầu tiên nếu có lịch pending.

### 2. Xem hồ sơ bệnh nhân trước khám
1. Bác sĩ nhấn vào lịch hẹn để xem chi tiết.
2. **Nếu lịch hẹn có `member_id`:** Hiển thị thông tin y tế của thành viên (tên, tuổi, giới tính, nhóm máu, dị ứng, bệnh nền, 3 lịch sử khám gần nhất, đơn thuốc đang dùng).
3. **Nếu lịch hẹn là khách (guest):** Hiển thị thông tin khách: tên, năm sinh, SĐT, lý do khám. Không có lịch sử y tế. Hiển thị thông báo: *"Đây là lịch hẹn khách — không có hồ sơ y tế"*.

### 3. Xác nhận lịch hẹn
1. Bác sĩ nhấn "Xác nhận" → `appointment.status = 'confirmed'`.
2. Tạo thông báo + gửi email cho bệnh nhân.

### 4. Từ chối lịch hẹn
1. Bác sĩ nhấn "Từ chối", **bắt buộc** nhập lý do.
2. Trong cùng 1 transaction:
   - `appointment.status = 'cancelled'`, lưu lý do.
   - **Giảm `slot.current_patients` đi 1.**
   - Tạo `refunds` với 100% hoàn tiền (nếu `payment_status = 'paid'`).
3. Gửi thông báo + email kèm lý do cho bệnh nhân.

### 5. Tự động hủy lịch pending sau 48h (cron)
1. Cron chạy mỗi giờ, tìm lịch hẹn `status = 'pending'`, `payment_status = 'paid'`, đã tạo > 48 giờ trước.
2. Tự động hủy: `status = 'cancelled'`, giảm `slot.current_patients`, tạo refund 100%.
3. Gửi email thông báo cho bệnh nhân: "Lịch hẹn tự động hủy do bác sĩ không xác nhận trong 48 giờ".

### 6. Hoàn thành ca khám
1. Bác sĩ nhấn "Hoàn thành" sau khi đã khám xong.
2. `appointment.status = 'completed'`.
3. **Ghi kết quả (B4) là tùy chọn** — bác sĩ có thể hoàn thành mà không cần ghi ngay. Nhưng nếu muốn kê đơn thuốc, phải vào B4.
4. Giao diện hiển thị nút "Ghi kết quả & Kê đơn" dẫn sang B4 (có thể làm sau, trong vòng 24 giờ).

## Vòng đời trạng thái
```
pending → confirmed  (bác sĩ xác nhận)
pending → cancelled  (bác sĩ từ chối, hoặc tự động sau 48h)
confirmed → completed
confirmed → cancelled  (bác sĩ hoặc admin hủy)
```

## Bảng dữ liệu liên quan
| Bảng | Mục đích |
|---|---|
| `appointments` | Cập nhật status, reason_cancel |
| `slots` | **Giảm current_patients khi từ chối hoặc hủy** |
| `members` | Thông tin y tế (nullable — guest không có) |
| `notifications` / email | Thông báo cho bệnh nhân |
| `refunds` | Tạo khi từ chối hoặc timeout (refund 100%) |

## API Endpoints
| Method | Endpoint | Auth | Mô tả |
|---|---|---|---|
| GET | `/api/appointments/doctor?tab=pending` | 👨‍⚕️ | Danh sách lịch hẹn theo tab |
| GET | `/api/appointments/:id` | 👨‍⚕️ | Chi tiết lịch hẹn |
| GET | `/api/appointments/:id/patient-profile` | 👨‍⚕️ | Hồ sơ bệnh nhân (kiểm tra quyền) |
| PATCH | `/api/appointments/:id/confirm` | 👨‍⚕️ | Xác nhận |
| PATCH | `/api/appointments/:id/reject` | 👨‍⚕️ | Từ chối (kèm lý do) → giảm slot |
| PATCH | `/api/appointments/:id/complete` | 👨‍⚕️ | Hoàn thành |

## Ràng buộc & Quy tắc nghiệp vụ
- Từ chối **bắt buộc** nhập lý do.
- Từ chối → **`slot.current_patients - 1`** trong cùng transaction.
- Từ chối → hoàn tiền **100%** bất kể thời điểm (nếu đã thanh toán).
- Lịch pending > 48h chưa xác nhận → **tự động hủy**, hoàn 100%.
- Bác sĩ chỉ thấy lịch hẹn của **chính mình**.
- Guest appointment: thay thế thông tin member bằng thông tin khách, hiển thị cảnh báo.
- Ghi kết quả B4 là **tùy chọn**, không bắt buộc ngay sau khi hoàn thành.

## Giao diện cần xây dựng
- Trang lịch hẹn bác sĩ (`/doctor/appointments`) — phân tab, badge đếm pending
- Drawer chi tiết lịch hẹn — phân biệt "thành viên gia đình" vs "khách"
- Dialog nhập lý do từ chối (bắt buộc, không để trống)
- Nút "Ghi kết quả" sau khi hoàn thành (dẫn sang B4)

## Chức năng liên quan
- **A5** — Bệnh nhân đặt lịch → bác sĩ nhận tại đây
- **A7** — Thông báo gửi khi trạng thái thay đổi
- **B4** — Tùy chọn ghi kết quả sau khi complete
- **C8** — Refund 100% khi bác sĩ từ chối
