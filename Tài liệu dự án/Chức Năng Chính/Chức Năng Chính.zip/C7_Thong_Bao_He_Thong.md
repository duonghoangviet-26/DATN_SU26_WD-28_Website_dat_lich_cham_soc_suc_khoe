# C7 — Gửi thông báo hệ thống

## Mô tả
Admin soạn và gửi thông báo hàng loạt. Sử dụng batch insert để tránh quá tải khi gửi đến nhiều người. Lịch sử thông báo có phân trang.

## Đối tượng sử dụng
| Người dùng | Vai trò |
|---|---|
| Admin | Soạn và gửi thông báo ngay lập tức |
| Bệnh nhân / Bác sĩ | Nhận thông báo (xem qua A7) |

## Luồng nghiệp vụ

### 1. Soạn thông báo
1. Admin vào `/admin/notifications/create`.
2. Điền: tiêu đề (tối đa 60 ký tự), nội dung chi tiết, link điều hướng (tùy chọn).
3. Chọn đối tượng nhận: Tất cả / Chỉ bệnh nhân (`role = 'user'`) / Chỉ bác sĩ (`role = 'doctor'`).
4. Hệ thống hiển thị số người nhận dự kiến (truy vấn đếm theo role).

### 2. Xem trước và xác nhận
1. Preview nội dung thông báo như người dùng sẽ thấy.
2. Admin xác nhận → gửi ngay.

### 3. Gửi thông báo (batch insert)
1. Server lấy danh sách user theo nhóm, lọc `status = 'active'`.
2. **Batch insert** vào `notifications` theo từng batch 100 records — tránh quá tải.
3. Cập nhật `system_notifications.status = 'sent'`, `sent_at`, `recipient_count`.

### 4. Xem lịch sử
1. Vào `/admin/notifications` — danh sách phân trang (20 mục/trang).
2. Xem: tiêu đề, ngày gửi, đối tượng, số người nhận.

## Bảng dữ liệu liên quan
| Bảng | Mục đích |
|---|---|
| `system_notifications` | Thông báo Admin tạo (1 bản gốc) |
| `notifications` | Bản sao cho từng user (batch insert) |
| `users` | Lấy danh sách theo role, chỉ user active |

## API Endpoints
| Method | Endpoint | Auth | Mô tả |
|---|---|---|---|
| GET | `/api/admin/system-notifications?page=1` | 🔑 | Lịch sử thông báo (phân trang) |
| POST | `/api/admin/system-notifications` | 🔑 | Tạo và gửi ngay |
| GET | `/api/admin/system-notifications/:id` | 🔑 | Chi tiết 1 thông báo |

## Ràng buộc & Quy tắc nghiệp vụ
- Tiêu đề tối đa **60 ký tự**.
- Thông báo đã gửi **không thể thu hồi**.
- Chỉ gửi cho user `status = 'active'` — bỏ qua tài khoản bị khoá.
- Sử dụng **batch insert 100 records/lần** — không insert tất cả cùng lúc.
- Phải có ít nhất **1 người nhận** — cảnh báo nếu nhóm được chọn không có ai.
- Lịch sử có **phân trang** (20 mục/trang).

## Giao diện cần xây dựng
- Trang lịch sử (`/admin/notifications`) — bảng phân trang
- Trang soạn mới (`/admin/notifications/create`)
- Hiển thị số người nhận dự kiến khi chọn đối tượng
- Preview thông báo trước khi gửi

## Chức năng liên quan
- **A7** — Người dùng nhận và xem thông báo này
