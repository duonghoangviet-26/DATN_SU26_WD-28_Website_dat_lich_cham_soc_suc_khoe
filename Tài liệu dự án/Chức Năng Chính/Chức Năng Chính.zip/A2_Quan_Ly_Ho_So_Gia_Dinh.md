# A2 — Quản lý hồ sơ gia đình

## Mô tả
Cho phép một tài khoản bệnh nhân quản lý sức khỏe cho nhiều thành viên trong gia đình. Chủ hộ mặc định là thành viên đầu tiên. Thông tin trong hồ sơ thành viên hoàn toàn độc lập với thông tin tài khoản.

## Đối tượng sử dụng
| Người dùng | Vai trò |
|---|---|
| Bệnh nhân (chủ hộ) | Tạo nhóm, thêm/sửa/xóa thành viên |

## Luồng nghiệp vụ

### 1. Tạo nhóm gia đình lần đầu
1. Sau đăng nhập lần đầu, bệnh nhân được gợi ý tạo nhóm gia đình.
2. Nhập tên nhóm (ví dụ: "Gia đình Nguyễn").
3. Hệ thống tạo bản ghi `families` liên kết `user_id`.
4. **Tự động tạo thành viên đầu tiên** từ thông tin tài khoản: họ tên, (ngày sinh + giới tính cần nhập thêm) → lưu vào `members` với `is_owner = true`.
5. Chủ hộ có thể bổ sung thêm thông tin y tế (nhóm máu, dị ứng, bệnh nền) cho bản ghi thành viên của mình.

### 2. Thêm thành viên
1. Bệnh nhân nhấn "Thêm thành viên".
2. Điền: họ tên, ngày sinh (bắt buộc, phải là quá khứ), giới tính, nhóm máu, dị ứng, bệnh nền.
3. Hệ thống lưu vào `members` với `is_owner = false`.
4. **Giới hạn:** Tối đa **10 thành viên** mỗi nhóm (bao gồm cả chủ hộ).
5. Hai thành viên được phép cùng tên — phân biệt bằng ngày sinh hiển thị kèm theo.

### 3. Sửa thông tin thành viên
1. Bệnh nhân chọn thành viên, cập nhật thông tin y tế.
2. **Thông tin trong `members` hoàn toàn độc lập với `users`** — sửa profile tài khoản (A1) không ảnh hưởng đến thành viên, và ngược lại. Đây là cố ý vì thông tin y tế cần ổn định.

### 4. Xoá thành viên
1. Bệnh nhân chọn xoá thành viên.
2. **Không thể xoá chủ hộ** (`is_owner = true`) — hiển thị thông báo rõ ràng.
3. Kiểm tra thành viên có lịch hẹn `pending` hoặc `confirmed` → nếu có, yêu cầu hủy lịch trước.
4. Sau khi xoá: **hồ sơ y tế không bị xoá vật lý** (soft delete) — `members.deleted_at` = NOW(). Dữ liệu lịch sử vẫn còn trong DB, chỉ ẩn khỏi giao diện.

### 5. Xoá nhóm gia đình
1. **Điều kiện:** Nhóm phải không có thành viên nào khác ngoài chủ hộ (đã xoá hết).
2. Nhóm không có lịch hẹn `pending` / `confirmed` nào.
3. Xác nhận 2 lần → xoá `families` và `members` (chủ hộ).
4. Nếu có thành viên khác hoặc lịch hẹn đang hoạt động → từ chối, hiển thị lý do.

## Bảng dữ liệu liên quan
| Bảng | Mục đích |
|---|---|
| `families` | Thông tin nhóm (tên, liên kết user_id) |
| `members` | Từng thành viên: thông tin y tế, is_owner, deleted_at |

## API Endpoints
| Method | Endpoint | Auth | Mô tả |
|---|---|---|---|
| POST | `/api/families` | ✅ | Tạo nhóm gia đình (kèm tạo thành viên chủ hộ) |
| GET | `/api/families/my` | ✅ | Lấy nhóm gia đình + danh sách thành viên |
| PUT | `/api/families/:id` | ✅ | Đổi tên nhóm |
| DELETE | `/api/families/:id` | ✅ | Xoá nhóm (kiểm tra điều kiện) |
| POST | `/api/families/:id/members` | ✅ | Thêm thành viên mới |
| PUT | `/api/members/:id` | ✅ | Cập nhật thông tin thành viên |
| DELETE | `/api/members/:id` | ✅ | Xoá thành viên (soft delete) |

## Ràng buộc & Quy tắc nghiệp vụ
- 1 tài khoản chỉ có **1 nhóm gia đình** duy nhất.
- Khi tạo nhóm → chủ hộ **tự động** là thành viên đầu tiên (`is_owner = true`).
- Thông tin `members` **độc lập** với `users` — sửa 1 bên không ảnh hưởng bên kia.
- **Không thể xoá chủ hộ** khỏi nhóm. Chỉ có thể sửa thông tin của họ.
- Tối đa **10 thành viên** mỗi nhóm (bao gồm chủ hộ).
- Ngày sinh phải là ngày trong **quá khứ**.
- Khi xoá thành viên → **soft delete** (giữ lại dữ liệu y tế, chỉ ẩn khỏi giao diện).
- Bệnh nhân chưa tạo nhóm gia đình → **không thể đặt lịch** cho thành viên, nhưng vẫn đặt được dưới dạng "khách" (guest) tại A5.

## Giao diện cần xây dựng
- Trang quản lý gia đình (`/family`) — danh sách thành viên dạng card
- Chủ hộ hiển thị badge "Chủ hộ" rõ ràng, không có nút xoá
- Modal thêm thành viên — có trường bắt buộc ngày sinh
- Modal sửa thông tin thành viên
- Dialog xoá: 2 bước xác nhận, hiển thị cảnh báo nếu còn lịch hẹn

## Chức năng liên quan
- **A1** — Thông tin chủ hộ lấy từ `users` khi tạo nhóm, sau đó độc lập
- **A3** — Hồ sơ khám gắn với từng `member_id`
- **A4** — Đơn thuốc và nhắc nhở gắn với từng thành viên
- **A5** — Khi đặt lịch, chọn khám cho thành viên nào
- **B3** — Bác sĩ xem thông tin thành viên trước khi khám
