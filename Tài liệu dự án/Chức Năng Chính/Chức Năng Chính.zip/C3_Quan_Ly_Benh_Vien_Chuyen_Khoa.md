# C3 — Quản lý bệnh viện & chuyên khoa

## Mô tả
Admin quản lý dữ liệu danh mục nền tảng. Có ràng buộc an toàn khi xóa hoặc ẩn bệnh viện đang có lịch hẹn active. Slug chuyên khoa tự tạo với xử lý trùng lặp.

## Đối tượng sử dụng
| Người dùng | Vai trò |
|---|---|
| Admin | Thêm, sửa, ẩn, xóa bệnh viện và chuyên khoa |
| Bác sĩ | Chọn từ danh sách này khi đăng ký hồ sơ (B1) |
| Bệnh nhân | Lọc bác sĩ theo bệnh viện/chuyên khoa khi đặt lịch (A5) |

## Luồng nghiệp vụ

### 1. Thêm bệnh viện
1. Admin điền: tên, địa chỉ, SĐT, email, giờ làm việc, mô tả.
2. **Tên bệnh viện phải là duy nhất** — server kiểm tra UNIQUE.
3. Lưu với `status = 'active'`.

### 2. Ẩn bệnh viện
1. Admin tắt trạng thái.
2. Server kiểm tra bệnh viện có lịch hẹn `pending` / `confirmed` không.
3. **Nếu có** → hiển thị cảnh báo: "Bệnh viện này còn [N] lịch hẹn đang hoạt động. Ẩn bệnh viện không hủy các lịch hẹn đó."
4. Admin xác nhận → `status = 'hidden'`. Lịch cũ vẫn giữ nguyên.
5. Bệnh viện ẩn không hiển thị cho bệnh nhân tìm kiếm, không hiển thị trong form đăng ký bác sĩ mới.

### 3. Xóa bệnh viện
1. Kiểm tra **đồng thời**:
   - Không có bác sĩ active liên kết (`doctor_hospitals`).
   - Không có lịch hẹn `pending` / `confirmed` / `completed` tại bệnh viện này.
2. Nếu còn → trả về lỗi 409 kèm mô tả chi tiết.
3. Gợi ý: "Hãy ẩn bệnh viện thay vì xóa."

### 4. Thêm chuyên khoa
1. Điền: tên, mô tả, icon URL.
2. Hệ thống tự tạo slug: "Tim mạch" → "tim-mach".
3. **Nếu slug trùng** (do tên gần giống) → tự thêm số: "tim-mach-2".
4. Lưu với `status = 'active'`.

### 5. Xóa chuyên khoa
1. Kiểm tra không có bác sĩ đang dùng chuyên khoa này.
2. Nếu có → từ chối xóa, hiển thị số bác sĩ liên quan.

## Bảng dữ liệu liên quan
| Bảng | Mục đích |
|---|---|
| `hospitals` | Danh sách bệnh viện (tên UNIQUE) |
| `specialties` | Danh sách chuyên khoa (slug UNIQUE) |
| `doctor_hospitals` | Kiểm tra khi xóa bệnh viện |
| `doctor_specialties` | Kiểm tra khi xóa chuyên khoa |
| `appointments` | Kiểm tra lịch active khi ẩn/xóa bệnh viện |

## API Endpoints
| Method | Endpoint | Auth | Mô tả |
|---|---|---|---|
| GET | `/api/hospitals` | ❌ | Danh sách bệnh viện active (public) |
| POST | `/api/hospitals` | 🔑 | Thêm bệnh viện |
| PUT | `/api/hospitals/:id` | 🔑 | Sửa thông tin |
| PATCH | `/api/hospitals/:id/status` | 🔑 | Ẩn/hiện (có cảnh báo nếu còn lịch) |
| DELETE | `/api/hospitals/:id` | 🔑 | Xóa (kiểm tra toàn diện) |
| GET | `/api/specialties` | ❌ | Danh sách chuyên khoa (public) |
| POST | `/api/specialties` | 🔑 | Thêm chuyên khoa (tự tạo slug) |
| PUT | `/api/specialties/:id` | 🔑 | Sửa |
| PATCH | `/api/specialties/:id/status` | 🔑 | Ẩn/hiện |
| DELETE | `/api/specialties/:id` | 🔑 | Xóa (kiểm tra bác sĩ liên quan) |

## Ràng buộc & Quy tắc nghiệp vụ
- Tên bệnh viện phải **UNIQUE** trong hệ thống.
- Ẩn bệnh viện khi có lịch active → **cảnh báo nhưng vẫn cho phép** (Admin quyết định).
- Xóa bệnh viện: kiểm tra **cả bác sĩ lẫn lịch hẹn**, không chỉ bác sĩ.
- Slug chuyên khoa: tự tạo từ tên, tự resolve conflict bằng suffix số.
- Bệnh viện/chuyên khoa ẩn không hiển thị trong tìm kiếm và form đăng ký.

## Giao diện cần xây dựng
- Trang bệnh viện (`/admin/hospitals`) — bảng + nút thêm mới
- Trang chuyên khoa (`/admin/specialties`) — hỗ trợ kéo thả thứ tự hiển thị
- Modal thêm/sửa với validation realtime
- Cảnh báo dạng modal khi ẩn/xóa có dữ liệu liên quan

## Chức năng liên quan
- **B1** — Bác sĩ chọn từ danh sách này
- **A5** — Bệnh nhân lọc bác sĩ theo bệnh viện/chuyên khoa
