# B1 — Quản lý hồ sơ bác sĩ

## Mô tả
Bác sĩ đăng ký hồ sơ chuyên môn. Hồ sơ phải được Admin duyệt (C2) trước khi hiển thị công khai. Tài khoản chỉ đổi role thành 'doctor' sau khi được duyệt.

## Đối tượng sử dụng
| Người dùng | Vai trò |
|---|---|
| Bác sĩ | Tạo và cập nhật hồ sơ chuyên môn |
| Admin | Duyệt hoặc từ chối hồ sơ (C2) |

## Luồng nghiệp vụ

### 1. Tạo hồ sơ bác sĩ lần đầu
1. Người dùng (đã đăng nhập, `role = 'user'`) vào `/doctor/register`.
2. Điền thông tin: tiểu sử, bằng cấp, kinh nghiệm, chuyên khoa (chọn từ danh sách C3), bệnh viện công tác (chọn từ C3), phí tư vấn (≥ 0, miễn phí là hợp lệ).
3. Nhấn "Gửi hồ sơ" → tạo `doctors` với `approval_status = 'pending'`.
4. `users.role` **vẫn là 'user'** — chưa đổi sang 'doctor'.
5. Admin nhận thông báo hồ sơ mới.

### 2. Sau khi được Admin duyệt (C2)
1. `doctors.approval_status = 'approved'`.
2. `users.role` **đổi thành 'doctor'** — thực hiện trong cùng transaction khi Admin duyệt.
3. Lần đăng nhập tiếp theo: redirect vào trang bác sĩ (`/doctor`).
4. Hồ sơ hiển thị công khai trên trang tìm kiếm của bệnh nhân.

### 3. Cập nhật hồ sơ (sau khi đã duyệt)
1. Bác sĩ vào `/doctor/profile`, chỉnh sửa thông tin.
2. Lưu → cập nhật bảng `doctors` ngay (không cần duyệt lại).
3. **Cập nhật không làm mất trạng thái `approved`.**

### 4. Hồ sơ bị từ chối → nộp lại
1. Bác sĩ nhận email kèm lý do từ chối.
2. Xem lý do trên giao diện, chỉnh sửa.
3. Nhấn "Gửi lại" → `approval_status = 'pending'` (lại chờ duyệt). `users.role` vẫn là `'user'`.
4. Tối đa **5 lần** nộp lại. Nếu vượt quá, phải liên hệ Admin.

### 5. Vai trò kép: bác sĩ vẫn dùng được chức năng bệnh nhân
- Sau khi được duyệt, người dùng có `role = 'doctor'` nhưng **vẫn truy cập được** các tính năng bệnh nhân (đặt lịch, quản lý gia đình...) nếu hệ thống cho phép route dual-access.
- Thực tế: bác sĩ dùng 2 màn hình riêng biệt (`/dashboard` và `/doctor`).

## Trạng thái hồ sơ
```
(chưa tạo)
  → pending      (bác sĩ submit)
  → approved     (Admin duyệt → users.role = 'doctor')
  → rejected     (Admin từ chối, kèm lý do)
rejected → pending (bác sĩ nộp lại, tối đa 5 lần)
```

## Bảng dữ liệu liên quan
| Bảng | Mục đích |
|---|---|
| `doctors` | Hồ sơ chuyên môn, approval_status, rejection_reason, submit_count |
| `doctor_specialties` | Liên kết bác sĩ ↔ chuyên khoa |
| `doctor_hospitals` | Liên kết bác sĩ ↔ bệnh viện |
| `users` | role đổi thành 'doctor' khi được duyệt |

## API Endpoints
| Method | Endpoint | Auth | Mô tả |
|---|---|---|---|
| POST | `/api/doctors` | ✅ | Tạo hồ sơ bác sĩ lần đầu |
| GET | `/api/doctors/my` | ✅ | Hồ sơ của user đang đăng nhập |
| PUT | `/api/doctors/:id` | 👨‍⚕️ | Cập nhật hồ sơ |
| POST | `/api/doctors/:id/resubmit` | ✅ | Nộp lại sau khi bị từ chối |
| GET | `/api/specialties` | ❌ | Danh sách chuyên khoa |
| GET | `/api/hospitals` | ❌ | Danh sách bệnh viện |

## Ràng buộc & Quy tắc nghiệp vụ
- 1 tài khoản chỉ có **1 hồ sơ bác sĩ**.
- `users.role = 'doctor'` chỉ được set khi Admin duyệt (C2) — không set khi bác sĩ submit.
- Hồ sơ chưa `approved` → không xuất hiện trong tìm kiếm, không tạo được lịch làm việc.
- Phí tư vấn có thể = 0 (miễn phí).
- Tối đa **5 lần** nộp lại (trường `doctors.submit_count`).
- Khi Admin ẩn bác sĩ (`is_visible = false`): bác sĩ biến mất khỏi tìm kiếm nhưng **lịch hẹn cũ vẫn giữ nguyên** và bác sĩ vẫn xử lý được.

## Giao diện cần xây dựng
- `/doctor/register` — form đăng ký hồ sơ
- `/doctor/profile` — xem và sửa hồ sơ đã được duyệt
- Hiển thị trạng thái: badge màu (pending/approved/rejected) + lý do từ chối nếu có
- Thanh đếm số lần nộp lại còn lại

## Chức năng liên quan
- **A1** — Phải có tài khoản trước, role đổi ở đây
- **C2** — Admin duyệt hồ sơ + đổi role
- **C3** — Danh sách bệnh viện và chuyên khoa
- **B2** — Phải được duyệt mới tạo được lịch làm việc
