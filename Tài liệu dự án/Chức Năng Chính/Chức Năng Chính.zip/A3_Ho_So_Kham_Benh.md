# A3 — Xem hồ sơ khám bệnh

## Mô tả
Lưu trữ và hiển thị lịch sử khám bệnh của từng thành viên. Hồ sơ tự động tạo sau khi bác sĩ hoàn thành ca khám (B4), hoặc bệnh nhân tự nhập thủ công. Lịch hẹn "khách" (guest) không có thành viên cụ thể cũng tạo được hồ sơ.

## Đối tượng sử dụng
| Người dùng | Vai trò |
|---|---|
| Bệnh nhân | Xem hồ sơ của từng thành viên, tự thêm hồ sơ thủ công |
| Bác sĩ | Chỉ đọc hồ sơ của bệnh nhân **trong phạm vi lịch hẹn liên quan** (B3) |

## Luồng nghiệp vụ

### 1. Xem lịch sử khám bệnh
1. Bệnh nhân chọn thành viên muốn xem.
2. Hệ thống trả về danh sách hồ sơ khám theo thứ tự mới nhất.
3. Nhấn vào từng hồ sơ để xem chi tiết: ngày khám, bệnh viện, bác sĩ, chẩn đoán, ghi chú, đơn thuốc, ngày tái khám.

### 2. Thêm hồ sơ thủ công
1. Bệnh nhân nhấn "Thêm hồ sơ", chọn thành viên.
2. Điền: ngày khám (không được là tương lai), tên bệnh viện, tên bác sĩ, lý do khám, chẩn đoán, ghi chú.
3. Hệ thống lưu với `appointment_id = NULL` (phân biệt hồ sơ tự nhập với hồ sơ từ lịch hẹn).

### 3. Hồ sơ tự động từ lịch hẹn (B4 kích hoạt)
1. Bác sĩ ghi kết quả sau khám → hệ thống tạo `medical_records`.
2. Nếu lịch hẹn có `member_id` (đặt cho thành viên) → `medical_records.member_id = member_id`.
3. Nếu lịch hẹn là khách (guest, không có member) → `medical_records.member_id = NULL`, lưu `guest_name` từ appointment.
4. Bệnh nhân nhận thông báo "Hồ sơ khám mới đã có".

### 4. Bác sĩ xem hồ sơ (B3)
1. Bác sĩ truy cập qua endpoint riêng: `GET /api/appointments/:id/patient-profile`.
2. Server kiểm tra: bác sĩ phải là người phụ trách lịch hẹn đó.
3. Nếu lịch hẹn có `member_id` → hiển thị thông tin y tế của thành viên (dị ứng, bệnh nền, lịch sử khám).
4. Nếu lịch hẹn là khách → hiển thị thông tin khách: tên, năm sinh, lý do khám (không có lịch sử y tế).

## Bảng dữ liệu liên quan
| Bảng | Mục đích |
|---|---|
| `medical_records` | Hồ sơ khám: ngày, bệnh viện, bác sĩ, chẩn đoán. `member_id` nullable (cho guest) |
| `examination_results` | Kết quả chi tiết do bác sĩ ghi (B4) |
| `members` | Thành viên sở hữu hồ sơ (nullable với guest) |
| `appointments` | Liên kết hồ sơ với lịch hẹn |

## API Endpoints
| Method | Endpoint | Auth | Mô tả |
|---|---|---|---|
| GET | `/api/members/:id/medical-records` | ✅ | Danh sách hồ sơ khám của một thành viên |
| POST | `/api/medical-records` | ✅ | Tạo hồ sơ thủ công (bệnh nhân) |
| GET | `/api/medical-records/:id` | ✅ | Chi tiết một hồ sơ |
| PUT | `/api/medical-records/:id` | ✅ | Sửa hồ sơ (chỉ hồ sơ `appointment_id = NULL`) |
| DELETE | `/api/medical-records/:id` | ✅ | Xoá hồ sơ (chỉ hồ sơ `appointment_id = NULL`) |
| GET | `/api/appointments/:id/patient-profile` | 👨‍⚕️ | Bác sĩ xem hồ sơ trước khám (kiểm tra quyền) |

## Ràng buộc & Quy tắc nghiệp vụ
- Hồ sơ có `appointment_id != NULL` (tự động từ khám bệnh) **không thể sửa hoặc xoá** bởi bệnh nhân.
- Bác sĩ chỉ xem hồ sơ của bệnh nhân **thuộc lịch hẹn của mình** — server verify `appointment.doctor_id = req.user.id`.
- Lịch hẹn khách (guest): `medical_records.member_id = NULL` là hợp lệ.
- Xoá thành viên (A2 soft delete) → hồ sơ của thành viên đó vẫn còn trong DB nhưng bệnh nhân không thấy nữa trên giao diện.
- Ngày khám hồ sơ thủ công không được là ngày **tương lai**.

## Giao diện cần xây dựng
- Trang hồ sơ khám (`/medical-records`) — chọn thành viên, timeline hồ sơ
- Trang chi tiết hồ sơ — đầy đủ thông tin kết quả, đơn thuốc
- Modal thêm hồ sơ thủ công — có chọn thành viên
- Phân biệt trực quan: hồ sơ tự động (có badge "Từ lịch hẹn") vs hồ sơ thủ công

## Chức năng liên quan
- **A2** — Hồ sơ gắn với từng thành viên
- **A4** — Đơn thuốc trong hồ sơ tạo reminders
- **B3** — Bác sĩ xem hồ sơ qua endpoint riêng
- **B4** — Bác sĩ ghi kết quả → hệ thống tạo hồ sơ tự động
