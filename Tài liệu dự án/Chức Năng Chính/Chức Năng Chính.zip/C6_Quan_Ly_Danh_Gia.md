# C6 — Quản lý đánh giá & phản hồi

## Mô tả
Bệnh nhân gửi đánh giá sau ca khám completed. Admin kiểm duyệt — khi ẩn đánh giá, rating trung bình bác sĩ tự cập nhật. Bác sĩ không thấy đánh giá đã bị Admin ẩn.

## Đối tượng sử dụng
| Người dùng | Vai trò |
|---|---|
| Bệnh nhân | Gửi đánh giá 1 lần sau ca khám `completed` |
| Admin | Xem tất cả, ẩn hoặc xóa đánh giá vi phạm |
| Bác sĩ | Xem đánh giá `visible` của mình (qua B5) |

## Luồng nghiệp vụ

### 1. Bệnh nhân gửi đánh giá
1. Sau khi lịch hẹn `completed`, nút "Đánh giá bác sĩ" xuất hiện trên trang chi tiết lịch hẹn.
2. Bệnh nhân chọn 1–5 sao, viết nhận xét (tùy chọn, tối đa 500 ký tự).
3. Lưu vào `reviews` với `status = 'visible'`.
4. **Không thể sửa hoặc gửi lại** sau khi đã gửi.
5. Nút "Đánh giá" biến mất sau khi đã gửi — thay bằng hiển thị đánh giá đã gửi.

### 2. Admin xem danh sách đánh giá
1. Vào `/admin/reviews`, danh sách phân trang.
2. Lọc theo: rating, bác sĩ, ngày, trạng thái (visible/hidden).
3. Đánh giá 1–2 sao **highlight màu đỏ** để Admin chú ý.

### 3. Admin ẩn đánh giá
1. Nhấn "Ẩn" → `review.status = 'hidden'`.
2. **Ngay lập tức:** tính lại `rating trung bình` của bác sĩ đó (chỉ từ `visible` reviews).
3. Bác sĩ **không thấy** đánh giá `hidden` trong trang B5 của mình.
4. Ghi `audit_logs`.

### 4. Admin xóa đánh giá
1. Nhấn "Xóa" và xác nhận.
2. **Xóa vật lý** bản ghi trong `reviews`.
3. **Ngay lập tức:** tính lại rating trung bình.
4. Ghi `audit_logs`.

## Bảng dữ liệu liên quan
| Bảng | Mục đích |
|---|---|
| `reviews` | Đánh giá: rating, comment, status (visible/hidden) |
| `appointments` | Liên kết 1-1: 1 lịch hẹn = tối đa 1 đánh giá |
| `doctors` | Cập nhật `avg_rating` sau khi ẩn/xóa đánh giá |
| `audit_logs` | Ghi lại thao tác Admin |

## API Endpoints
| Method | Endpoint | Auth | Mô tả |
|---|---|---|---|
| POST | `/api/appointments/:id/review` | ✅ | Bệnh nhân gửi đánh giá |
| GET | `/api/doctors/:id/reviews?page=1` | ❌ | Đánh giá visible công khai (có phân trang) |
| GET | `/api/admin/reviews?page=1&rating=1` | 🔑 | Tất cả đánh giá (Admin) |
| PATCH | `/api/admin/reviews/:id/hide` | 🔑 | Ẩn đánh giá (cập nhật rating ngay) |
| DELETE | `/api/admin/reviews/:id` | 🔑 | Xóa đánh giá (cập nhật rating ngay) |

## Ràng buộc & Quy tắc nghiệp vụ
- Chỉ gửi đánh giá khi `appointment.status = 'completed'`.
- Mỗi lịch hẹn chỉ được đánh giá **1 lần** — không sửa, không gửi lại.
- Rating từ **1 đến 5** (số nguyên).
- Sau khi Admin ẩn hoặc xóa → rating trung bình **cập nhật ngay**.
- Bác sĩ **không thấy** đánh giá `hidden` trong trang B5.
- Đánh giá `hidden` vẫn hiển thị với Admin (có label "Đã ẩn").

## Giao diện cần xây dựng
- Nút "Đánh giá" trên chi tiết lịch hẹn completed (biến mất sau khi đã đánh giá)
- Modal đánh giá: chọn sao + nhập nhận xét
- Trang admin (`/admin/reviews`) — bảng, highlight sao thấp, phân trang
- Nút Ẩn / Xóa trên mỗi đánh giá

## Chức năng liên quan
- **A5** — Đánh giá gắn với lịch hẹn completed
- **B5** — Bác sĩ xem đánh giá visible của mình
