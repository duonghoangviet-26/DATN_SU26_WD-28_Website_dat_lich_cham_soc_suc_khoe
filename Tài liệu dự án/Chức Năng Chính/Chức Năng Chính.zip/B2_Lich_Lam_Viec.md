# B2 — Quản lý lịch làm việc

## Mô tả
Bác sĩ tạo và quản lý khung giờ khám (slot) cho từng ngày. Hệ thống tự cập nhật slot khi bệnh nhân đặt hoặc hủy lịch. Bác sĩ bị ẩn → slot không hiển thị cho bệnh nhân mới.

## Đối tượng sử dụng
| Người dùng | Vai trò |
|---|---|
| Bác sĩ | Tạo, sửa, xoá lịch làm việc và khung giờ |

## Luồng nghiệp vụ

### 1. Xem lịch làm việc
1. Bác sĩ vào `/doctor/schedule` → calendar tháng/tuần.
2. Màu sắc theo trạng thái slot trong ngày:
   - **Xanh lá**: còn nhiều chỗ.
   - **Cam**: ≥ 80% đã đặt.
   - **Đỏ**: đã đầy.
   - **Xám**: không có lịch.

### 2. Tạo lịch ngày mới
1. Bác sĩ nhấn vào ngày trên calendar.
2. **Ngày phải từ hôm nay trở đi** — không tạo lịch cho ngày quá khứ.
3. Hệ thống tạo `doctor_schedules` nếu chưa có cho ngày đó (UNIQUE: doctor_id + date).

### 3. Thêm slot (khung giờ)
1. Nhập: giờ bắt đầu, giờ kết thúc, số bệnh nhân tối đa (≥ 1).
2. Server kiểm tra:
   - `end_time > start_time`.
   - Không trùng khung giờ với slot khác cùng ngày (overlap check).
3. Lưu vào `slots` với `current_patients = 0`.

### 4. Sửa slot
1. Bác sĩ muốn sửa slot.
2. **Chỉ sửa được nếu `slot.current_patients = 0`** (chưa có ai đặt).
3. Nếu đã có người đặt → chỉ cho phép tăng `max_patients` (không giảm xuống dưới `current_patients`).
4. Không được giảm `max_patients` xuống thấp hơn `current_patients`.

### 5. Xoá slot
1. Kiểm tra không có lịch hẹn `pending` / `confirmed` trong slot.
2. Nếu có → từ chối xoá, hiển thị số lượng lịch hẹn còn đang hoạt động.
3. Nếu không → xoá `slots`.

### 6. Bác sĩ bị ẩn (is_visible = false)
1. Slot của bác sĩ bị ẩn **không hiển thị** cho bệnh nhân mới tìm kiếm.
2. Lịch hẹn cũ đã đặt vẫn giữ nguyên và bác sĩ vẫn xử lý được.

## Bảng dữ liệu liên quan
| Bảng | Mục đích |
|---|---|
| `doctor_schedules` | Ngày làm việc (UNIQUE: doctor_id + date) |
| `slots` | Khung giờ: start_time, end_time, max/current_patients |
| `doctors` | Kiểm tra approval_status và is_visible |

## API Endpoints
| Method | Endpoint | Auth | Mô tả |
|---|---|---|---|
| GET | `/api/doctors/:id/schedules?month=2026-06` | ✅ | Lịch làm việc theo tháng |
| POST | `/api/doctor-schedules` | 👨‍⚕️ | Tạo lịch cho một ngày |
| POST | `/api/doctor-schedules/:id/slots` | 👨‍⚕️ | Thêm slot vào ngày |
| PUT | `/api/slots/:id` | 👨‍⚕️ | Sửa slot (kiểm tra điều kiện) |
| DELETE | `/api/slots/:id` | 👨‍⚕️ | Xoá slot (chỉ khi current=0) |

## Ràng buộc & Quy tắc nghiệp vụ
- Phải có `approval_status = 'approved'` mới tạo được lịch.
- Không tạo lịch cho ngày **quá khứ**.
- Hai slot không được **trùng hoặc giao nhau** khung giờ cùng ngày.
- `max_patients >= 1` và `max_patients >= current_patients` luôn đúng.
- Không xoá slot khi còn lịch hẹn `pending` / `confirmed`.
- Sửa slot chỉ khi `current_patients = 0`, hoặc chỉ tăng `max_patients`.
- Bác sĩ `is_visible = false` → slot ẩn với bệnh nhân mới, nhưng lịch cũ không bị ảnh hưởng.

## Giao diện cần xây dựng
- Calendar tháng `/doctor/schedule`
- Panel danh sách slot của ngày được chọn
- Modal thêm/sửa slot — validate overlap ngay khi nhập
- Tooltip khi xoá slot: "Không thể xoá — còn 3 lịch hẹn đang hoạt động"

## Chức năng liên quan
- **B1** — Phải được duyệt mới tạo lịch
- **A5** — Bệnh nhân thấy và đặt slot trống
- **B3** — Slot đầy khi bệnh nhân đặt đủ chỗ
